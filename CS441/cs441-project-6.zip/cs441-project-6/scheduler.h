/*
 *
 *
 * CS 441/541: Disk Algorithm Simulator (Project 6)
 */
#include <stdio.h>
/* For atoi */
#include <stdlib.h>
/* For String operations - strlen */
#include <string.h>
/* For isdigit */
#include <ctype.h>
/* For bool type */
#include <stdbool.h>


/******************************
 * Defines
 ******************************/
// Maximum per-line length from the files
#define MAX_INPUT_LINE 1024


/******************************
 * Structures
 ******************************/


/******************************
 * Global Variables
 ******************************/
int startPos;
int startDir;
int numCylinder;
int numRequests;
int* requests;

/******************************
 * Function declarations
 ******************************/
 int getFCFS();
 int getSSTF();
 int getSCAN();
 int getCSCAN();
 int getLOOK();
 int getCLOOK();
