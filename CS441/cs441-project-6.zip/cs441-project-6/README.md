# CS441/541 Project 6

## Author(s):
Kevin Minter

## Date:
12/10/17

## Description:
Gets expected values from the disk access algorithms

## How to build the software
Use Make File

## How to use the software
Provide it with a formatted file and -h # and -d 0 | 1

## How the software was tested
Files in Given Tests and Tests

## Test Suite
No specific Suite

## Known bugs and problem areas
None
