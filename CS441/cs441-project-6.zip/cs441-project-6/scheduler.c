/*
 * CS 441/541: Disk Algorithm Simulator (Project 6)
 * Kevin Minter
 */
#include "scheduler.h"

int main(int argc, char **argv) {
  if(argc != 6){
    printf("Invalid Number of Arguements\n");
    return -1;
  }
  int fileArg = 0;
  int i;
  for(i = 1; i < argc; i++){
    if(strcmp(argv[i],"-h") == 0){
      startPos = atoi(argv[++i]);
    }else if(strcmp(argv[i],"-d") == 0){
      startDir = atoi(argv[++i]);
    }else{
      fileArg = i;
    }
  }
  FILE *input = fopen(argv[fileArg],"r");
  fscanf(input, "%d\n", &numCylinder);
  fscanf(input, "%d\n", &numRequests);
  requests = malloc(sizeof(int) * numRequests);
  for(i = 0; i < numRequests; i++){
    fscanf(input, "%d\n", &requests[i]);
    if(requests[i] >= numCylinder || requests[i] < 0){
      printf("Invalid Request in File\n");
      return -1;
    }
  }
  if(startPos >= numCylinder || startPos < 0){
    printf("Invalid Starting Position Provided\n");
    return -1;
  }
  printf("#-------------------------------\n# Queue File          : %s\n# Num. Disk Cylinders : %d\n# Head Position       : %d\n# Head Direction      : ",argv[fileArg], numCylinder, startPos);
  if(startDir == 0){
    printf("Toward 0");
  }else if(startDir == 1){
    printf("Toward last cylinder");
  }else{
    printf("Invalid Direction Provided\n");
    return -1;
  }
  printf("\n#-------------------------------\n");
  int fcfs = getFCFS(requests, numRequests);
  int sstf = getSSTF(requests, numRequests);
  int scan = getSCAN(requests, numRequests);
  int cscan = getCSCAN(requests, numRequests);
  int look = getLOOK(requests, numRequests);
  int clook = getCLOOK(requests, numRequests);
  printf("# %5d 	 FCFS\n# %5d 	 SSTF\n# %5d 	 SCAN\n# %5d 	 C-SCAN\n# %5d 	 LOOK\n# %5d 	 C-LOOK\n",fcfs,sstf,scan,cscan,look,clook);
  return 0;
}

//Calculates cost of FCFS given the requests provided
int getFCFS(){
  int total = 0;
  int curPos = startPos;
  int i;
  for(i = 0; i < numRequests; i++){
    total += abs(curPos - requests[i]);
    curPos = requests[i];
  }
  return total;
}

//Calculates cost of SSTF given the requests provided
int getSSTF(){
  int total = 0;
  int curPos = startPos;
  int i, j;
  int* done = malloc(sizeof(int) * numRequests);
  for(i = 0; i < numRequests; i++){
    done[i] = 0;
  }
  for(i = 0; i < numRequests; i++){
    int curBest = -1;
    int bestVal = -1;
    for(j = 0; j < numRequests; j++){
      if(done[j] == 0 && (bestVal == -1 || abs(curPos - requests[j]) < bestVal)){
        curBest = j;
        bestVal = abs(curPos - requests[j]);
      }
    }
    done[curBest] = 1;
    curPos = requests[curBest];
    total += bestVal;
  }
  return total;
}

//Calculates cost of SCAN given the requests provided
//Calculated using the goals when going in a direction assumes stopping at any new node it passes
int getSCAN(){
  int i;
  if(startDir == 0){
    int highestIndex = 0;
    for(i = 1; i < numRequests; i++){
      if(requests[i] > requests[highestIndex]){
        highestIndex = i;
      }
    }
    if(requests[highestIndex] > startPos){
      return startPos + requests[highestIndex];
    }else{
      int lowestIndex = 0;
      for(i = 1; i < numRequests; i++){
        if(requests[i] < requests[lowestIndex]){
          lowestIndex = i;
        }
      }
      return startPos - requests[lowestIndex];
    }
  }else{
    int lowestIndex = 0;
    for(i = 1; i < numRequests; i++){
      if(requests[i] < requests[lowestIndex]){
        lowestIndex = i;
      }
    }
    if(requests[lowestIndex] < startPos){
      return (numCylinder-1 - startPos) + (numCylinder-1 - requests[lowestIndex]);
    }else{
      int highestIndex = 0;
      for(i = 1; i < numRequests; i++){
        if(requests[i] > requests[highestIndex]){
          highestIndex = i;
        }
      }
      return requests[highestIndex] - startPos;
    }
  }
}

//Calculates cost of CSCAN given the requests provided
//Calculated using the goals when going in a direction assumes stopping at any new node it passes
int getCSCAN(){
  int i;
  if(startDir == 0){
    int firstHighIndex = -1;
    for(i = 0; i < numRequests; i++){
      if(requests[i] > startPos && (firstHighIndex == -1 || requests[i] < requests[firstHighIndex])){
        firstHighIndex = i;
      }
    }
    if(firstHighIndex != -1){
      return startPos + (numCylinder-1) + (numCylinder-1 - requests[firstHighIndex]);
    }else{
      int lowestIndex = 0;
      for(i = 1; i < numRequests; i++){
        if(requests[i] < requests[lowestIndex]){
          lowestIndex = i;
        }
      }
      return startPos - requests[lowestIndex];
    }
  }else{
    int firstLowIndex = -1;
    for(i = 0; i < numRequests; i++){
      if(requests[i] < startPos && (firstLowIndex == -1 || requests[i] > requests[firstLowIndex])){
        firstLowIndex = i;
      }
    }
    if(firstLowIndex != -1){
      return (numCylinder-1 - startPos) + (numCylinder-1) + requests[firstLowIndex];
    }else{
      int highestIndex = 0;
      for(i = 1; i < numRequests; i++){
        if(requests[i] > requests[highestIndex]){
          highestIndex = i;
        }
      }
      return requests[highestIndex] - startPos;
    }
  }
}

//Calculates cost of LOOK given the requests provided
//Calculated using the goals when going in a direction assumes stopping at any new node it passes
int getLOOK(){
  int i;
  int lowestIndex = 0;
  int highestIndex = 0;
  for(i = 1; i < numRequests; i++){
    if(requests[i] < requests[lowestIndex]){
      lowestIndex = i;
    }
    if(requests[i] > requests[highestIndex]){
      highestIndex = i;
    }
  }
  if(startDir == 0){
    if(requests[lowestIndex] < startPos && requests[highestIndex] > startPos){
      return (startPos - requests[lowestIndex]) + (requests[highestIndex] - requests[lowestIndex]);
    }else if(requests[highestIndex] > startPos){
      return requests[highestIndex] - startPos;
    }else{
      return startPos - requests[lowestIndex];
    }
  }else{
    if(requests[highestIndex] > startPos && requests[lowestIndex] < startPos){
      return (requests[highestIndex] - startPos) + (requests[highestIndex] - requests[lowestIndex]);
    }else if(requests[lowestIndex] < startPos){
      return startPos - requests[lowestIndex];
    }else{
      return requests[highestIndex] - startPos;
    }
  }
}

//Calculates cost of CLOOK given the requests provided
//Calculated using the goals when going in a direction assumes stopping at any new node it passes
int getCLOOK(){
  int i;
  int lowestIndex = 0;
  int highestIndex = 0;
  for(i = 1; i < numRequests; i++){
    if(requests[i] < requests[lowestIndex]){
      lowestIndex = i;
    }
    if(requests[i] > requests[highestIndex]){
      highestIndex = i;
    }
  }
  if(startDir == 0){
    int firstHighIndex = -1;
    for(i = 0; i < numRequests; i++){
      if(requests[i] > startPos && (firstHighIndex == -1 || requests[i] < requests[firstHighIndex])){
        firstHighIndex = i;
      }
    }
    if(requests[lowestIndex] <= startPos && requests[highestIndex] > startPos){
      return (startPos - requests[lowestIndex]) + (requests[highestIndex] - requests[lowestIndex]) + (requests[highestIndex] - requests[firstHighIndex]);
    }else if(requests[highestIndex] > startPos){
      return (requests[highestIndex] - startPos) + (requests[highestIndex] - requests[lowestIndex]);
    }else{
      return startPos - requests[lowestIndex];
    }
  }else{
    int firstLowIndex = -1;
    for(i = 0; i < numRequests; i++){
      if(requests[i] < startPos && (firstLowIndex == -1 || requests[i] > requests[firstLowIndex])){
        firstLowIndex = i;
      }
    }
    if(requests[highestIndex] >= startPos && requests[lowestIndex] < startPos){
      return (requests[highestIndex] - startPos) + (requests[highestIndex] - requests[lowestIndex]) + (requests[firstLowIndex] - requests[lowestIndex]);
    }else if(requests[lowestIndex] < startPos){
      return (startPos - requests[lowestIndex]) + (requests[highestIndex] - requests[lowestIndex]);
    }else{
      return requests[highestIndex] - startPos;
    }
  }
}
